import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useSubmitContribution, useGetContributionStats, getGetContributionStatsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { AnimatedNumber } from "@/components/animated-number";
import { Starfield } from "@/components/starfield";
import { Link } from "wouter";

export default function Home() {
  const [numberInput, setNumberInput] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading } = useGetContributionStats({
    query: {
      queryKey: getGetContributionStatsQueryKey()
    }
  });

  const submitMutation = useSubmitContribution();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(numberInput);
    if (isNaN(num) || numberInput.trim() === "") {
      toast({
        title: "Invalid number",
        description: "Please enter a valid number to contribute.",
        variant: "destructive"
      });
      return;
    }

    submitMutation.mutate(
      { data: { number: num } },
      {
        onSuccess: () => {
          setNumberInput("");
          toast({
            title: "Contribution accepted",
            description: "Your number has joined the collective.",
          });
          queryClient.invalidateQueries({ queryKey: getGetContributionStatsQueryKey() });
        },
        onError: () => {
          toast({
            title: "Contribution failed",
            description: "There was a disruption in the signal. Please try again.",
            variant: "destructive"
          });
        }
      }
    );
  };

  return (
    <div className="min-h-[100dvh] flex flex-col relative overflow-hidden text-primary-foreground font-mono">
      <Starfield />
      
      <main className="flex-1 flex flex-col items-center justify-center p-6 max-w-4xl mx-auto w-full">
        <div className="text-center space-y-12 w-full animate-in fade-in zoom-in duration-1000">
          
          <div className="space-y-4">
            <h2 className="text-sm uppercase tracking-[0.3em] text-primary/80 font-semibold">The Global Collective</h2>
            <div className="text-7xl md:text-9xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-primary/60 float-anim drop-shadow-[0_0_30px_rgba(139,92,246,0.3)]">
              {isLoading ? "..." : <AnimatedNumber value={stats?.sum || 0} />}
            </div>
            <p className="text-muted-foreground max-w-lg mx-auto text-sm md:text-base leading-relaxed">
              A living, breathing global counter. Submit a number, no matter how small, and watch the collective total grow over time.
            </p>
          </div>

          <div className="max-w-md mx-auto w-full">
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
              <Input
                type="number"
                value={numberInput}
                onChange={(e) => setNumberInput(e.target.value)}
                placeholder="Enter a number..."
                className="bg-card/50 backdrop-blur-sm border-primary/20 text-center sm:text-left h-14 text-lg focus-visible:ring-primary/50 placeholder:text-muted-foreground/50"
                disabled={submitMutation.isPending}
                data-testid="input-number"
              />
              <Button 
                type="submit" 
                size="lg" 
                className="h-14 px-8 text-base bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-300 hover:shadow-[0_0_20px_rgba(139,92,246,0.4)]"
                disabled={submitMutation.isPending}
                data-testid="button-submit"
              >
                {submitMutation.isPending ? "Transmitting..." : "Contribute"}
              </Button>
            </form>
          </div>

          <div className="pt-12 grid grid-cols-2 gap-8 border-t border-primary/10">
            <div className="space-y-2">
              <div className="text-3xl font-bold">
                {isLoading ? "-" : <AnimatedNumber value={stats?.count || 0} />}
              </div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">Total Contributions</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold">
                {isLoading ? "-" : <AnimatedNumber value={stats?.uniqueIps || 0} />}
              </div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">Unique Signals</div>
            </div>
          </div>
          
        </div>

        {stats?.recentContributions && stats.recentContributions.length > 0 && (
          <div className="w-full mt-24 max-w-2xl text-left animate-in slide-in-from-bottom-12 fade-in duration-1000 delay-300 fill-mode-both">
            <h3 className="text-xs uppercase tracking-[0.2em] text-primary/60 mb-6 border-b border-primary/10 pb-2">Recent Signals</h3>
            <div className="space-y-3">
              {stats.recentContributions.map((contrib, i) => (
                <div 
                  key={contrib.id} 
                  className="flex justify-between items-center text-sm py-2 px-4 rounded bg-card/30 border border-primary/5 backdrop-blur-sm"
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <span className="text-primary font-bold">+{new Intl.NumberFormat().format(contrib.number)}</span>
                  <span className="text-muted-foreground text-xs opacity-60">
                    {new Date(contrib.submittedAt).toLocaleTimeString(undefined, { 
                      hour: '2-digit', minute: '2-digit', second: '2-digit' 
                    })}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <footer className="p-6 text-center text-xs text-muted-foreground/50 z-10">
        <Link href="/admin" className="hover:text-primary transition-colors" data-testid="link-admin">
          Admin Terminal
        </Link>
      </footer>
    </div>
  );
}
