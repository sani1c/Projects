import React from "react";
import { Link } from "wouter";
import { useListContributions, getListContributionsQueryKey } from "@workspace/api-client-react";
import { Starfield } from "@/components/starfield";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft } from "lucide-react";
import { AnimatedNumber } from "@/components/animated-number";

export default function Admin() {
  const { data, isLoading } = useListContributions({
    query: {
      queryKey: getListContributionsQueryKey()
    }
  });

  return (
    <div className="min-h-[100dvh] flex flex-col relative overflow-hidden bg-background text-foreground font-mono">
      <Starfield />
      
      <div className="p-6 md:p-12 max-w-6xl mx-auto w-full z-10 animate-in fade-in duration-700">
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <Link href="/" className="inline-flex items-center text-sm text-primary/60 hover:text-primary transition-colors mb-6" data-testid="link-home">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Return to Collective
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tighter">Admin Terminal</h1>
            <p className="text-muted-foreground mt-2">Unfiltered data stream of all contributions.</p>
          </div>
          
          <div className="flex gap-8 bg-card/40 p-4 rounded-lg border border-primary/10 backdrop-blur-md">
            <div>
              <div className="text-2xl font-bold text-primary">
                {isLoading ? <Skeleton className="h-8 w-24" /> : <AnimatedNumber value={data?.total || 0} />}
              </div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">Total Sum</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary">
                {isLoading ? <Skeleton className="h-8 w-16" /> : <AnimatedNumber value={data?.contributions.length || 0} />}
              </div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">Entries</div>
            </div>
          </div>
        </header>

        <div className="bg-card/50 backdrop-blur-md border border-primary/20 rounded-xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-card/80">
                <TableRow className="border-primary/20 hover:bg-transparent">
                  <TableHead className="w-[100px] text-primary/80">ID</TableHead>
                  <TableHead className="text-primary/80">Number</TableHead>
                  <TableHead className="text-primary/80">IP Address</TableHead>
                  <TableHead className="text-right text-primary/80">Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i} className="border-primary/10">
                      <TableCell><Skeleton className="h-4 w-8" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-4 w-32 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : data?.contributions.length === 0 ? (
                  <TableRow className="border-primary/10 hover:bg-card/60">
                    <TableCell colSpan={4} className="h-32 text-center text-muted-foreground">
                      No contributions recorded yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  data?.contributions.map((contrib) => (
                    <TableRow key={contrib.id} className="border-primary/10 hover:bg-primary/5 transition-colors">
                      <TableCell className="text-muted-foreground">#{contrib.id}</TableCell>
                      <TableCell className="font-bold text-primary">+{new Intl.NumberFormat().format(contrib.number)}</TableCell>
                      <TableCell className="font-mono text-xs opacity-70">{contrib.ipAddress}</TableCell>
                      <TableCell className="text-right text-muted-foreground text-sm">
                        {new Date(contrib.submittedAt).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
}
