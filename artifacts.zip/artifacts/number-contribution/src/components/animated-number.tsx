import React, { useEffect, useRef, useState } from "react";

interface AnimatedNumberProps {
  value: number;
  className?: string;
  duration?: number;
}

export function AnimatedNumber({ value, className = "", duration = 1000 }: AnimatedNumberProps) {
  const [displayValue, setDisplayValue] = useState(value);
  const startTime = useRef<number | null>(null);
  const startValue = useRef(displayValue);
  
  useEffect(() => {
    if (displayValue === value) return;
    
    startValue.current = displayValue;
    startTime.current = null;
    let animationFrameId: number;

    const animate = (timestamp: number) => {
      if (!startTime.current) startTime.current = timestamp;
      const progress = timestamp - startTime.current;
      const percentage = Math.min(progress / duration, 1);
      
      // Easing function (easeOutExpo)
      const easeOut = 1 - Math.pow(1 - percentage, 3);
      
      const currentVal = Math.round(startValue.current + (value - startValue.current) * easeOut);
      setDisplayValue(currentVal);

      if (progress < duration) {
        animationFrameId = requestAnimationFrame(animate);
      } else {
        setDisplayValue(value);
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [value, duration]); // Intentionally not including displayValue to avoid re-triggering

  return (
    <span className={`tabular-nums ${className}`}>
      {new Intl.NumberFormat().format(displayValue)}
    </span>
  );
}
