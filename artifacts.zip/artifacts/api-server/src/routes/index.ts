import { Router, type IRouter } from "express";
import healthRouter from "./health";
import contributionsRouter from "./contributions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(contributionsRouter);

export default router;
