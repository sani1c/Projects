import { Router } from "express";
import { db, contributionsTable } from "@workspace/db";
import { SubmitContributionBody } from "@workspace/api-zod";
import { desc, sql } from "drizzle-orm";

const router = Router();

function getClientIp(req: import("express").Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string") {
    return forwarded.split(",")[0].trim();
  }
  return req.socket.remoteAddress ?? "unknown";
}

router.post("/contributions", async (req, res) => {
  const parsed = SubmitContributionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input: number is required" });
    return;
  }

  const ipAddress = getClientIp(req);
  const [contribution] = await db
    .insert(contributionsTable)
    .values({
      number: String(parsed.data.number),
      ipAddress,
    })
    .returning();

  res.status(201).json({
    id: contribution.id,
    number: Number(contribution.number),
    ipAddress: contribution.ipAddress,
    submittedAt: contribution.submittedAt.toISOString(),
  });
});

router.get("/contributions", async (req, res) => {
  const rows = await db
    .select()
    .from(contributionsTable)
    .orderBy(desc(contributionsTable.submittedAt));

  res.json({
    contributions: rows.map((r) => ({
      id: r.id,
      number: Number(r.number),
      ipAddress: r.ipAddress,
      submittedAt: r.submittedAt.toISOString(),
    })),
    total: rows.length,
  });
});

router.get("/contributions/stats", async (req, res) => {
  const [agg] = await db
    .select({
      sum: sql<string>`coalesce(sum(number), 0)`,
      count: sql<number>`count(*)::int`,
      uniqueIps: sql<number>`count(distinct ip_address)::int`,
    })
    .from(contributionsTable);

  const recent = await db
    .select()
    .from(contributionsTable)
    .orderBy(desc(contributionsTable.submittedAt))
    .limit(10);

  res.json({
    sum: Number(agg.sum),
    count: agg.count,
    uniqueIps: agg.uniqueIps,
    recentContributions: recent.map((r) => ({
      id: r.id,
      number: Number(r.number),
      ipAddress: r.ipAddress,
      submittedAt: r.submittedAt.toISOString(),
    })),
  });
});

export default router;
